
import java.util.Scanner;

public class Pila {

	private int[] p;
	private int e;
	private int t = -1;
	
	public int pop(int[] p) {
		e = p[p.length]	;	
		t--;
		return e;
	}
	
	
	public int push(int[] p, int x) {
		t++;
		x = p[p.length]	;	
		return x;
	}
	
	public int peek(int[] p) {
		e = p[p.length]	;	
		return e;
	}
	
}
